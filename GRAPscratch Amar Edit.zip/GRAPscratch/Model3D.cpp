#include "Model3D.h"
#include <iostream>

Model3D::Model3D()
{
	//constructor values for Model3D
	mTheta = 0;
	position = glm::vec3(0.0f, 0.0f, 0.0f);
	rotationAxis = glm::vec3(0.0f, 0.0f, 0.0f);
	scale = glm::vec3(1.0f, 1.0f, 1.0f);
}

void Model3D::loadModel(string filename) {
	//implement if want pero di naman needed

}

void Model3D::drawModel(GLuint VAO, vector<GLuint>& mesh_indices)
{
	/*
	draws the model using the VAO and mesh indices of the model

	glbindVertexArray(VAO) - binds the vertex to the object model

	glDrawElements(GL_TRIANGLES, mesh_indices.size(), GL_UNSIGNED_INT, 0) - draws the model using the mesh_indices of the model

	This function is called 

	*/
	glBindVertexArray(VAO);
	glDrawElements(GL_TRIANGLES, mesh_indices.size(), GL_UNSIGNED_INT, 0);
}

void Model3D::setPosition(glm::mat4& transformation, glm::vec3& transPos)
{
	/*
	sets the postion of the model using transPos vector
	and tranformation matrix using glm::translate() to compute the value of the position
	before setting it to the posMatrix variable

		transformation = current transformation matrix of the model
		transPos = position to be set


	*/
	glm::mat4 identity_matrix = glm::mat4(1.0f);
	position = transPos;
	transformation = glm::translate(
		identity_matrix,
		position
	);
	posMatrix = transformation;
}

void Model3D::setRotation(glm::mat4& transformation, float theta, char axis)
{		
	/*
	rotates the model using glm::rotate()

	the rotation uses a quaternion matrix for rotating the model

	each if condition corresponds to which axis the model will rotate

	transformation = current transformation matrix of the model
	theta = angle of rotation
	axis = which axis the object is set

	after rotating the model, the value is set to the posMatrix variable
	*/
	mTheta = theta;
	if (axis == 'x' || axis == 'X')
	{
		transformation = glm::rotate(
			transformation,
			glm::radians(theta),
			glm::normalize(glm::vec3(1.0f, 0.0f, 0.0f))
		);
	}
	else if (axis == 'y' || axis == 'Y')
	{
		transformation = glm::rotate(
			transformation,
			glm::radians(theta),
			glm::normalize(glm::vec3(0.0f, 1.0f, 0.0f))
		);
	}
	else if (axis == 'z' || axis == 'Z')
	{
		transformation = glm::rotate(
			transformation,
			glm::radians(theta),
			glm::normalize(glm::vec3(0.0f, 0.0f, 1.0f))
		);
	}
	else
	{
		cout << "Invalid axis" << endl;
	}
}

void Model3D::setScale(glm::mat4& transformation, glm::vec3& scalePos)
{
	/*
	sets the scale of the model using glm::scale()

	scalePos = scale position to be applied

	transformation = current transformation matrix of the model
	*/
	scale = scalePos;
	transformation = glm::scale(
		transformation,
		scalePos
	);
}

glm::mat4 Model3D::getTransMatrix()//gets the transformation matrix of the model:
{
	return posMatrix;
}

glm::vec3 Model3D::getPos()//gets the position of the model:

{
	return position;
}

glm::vec3 Model3D::getScale() // gets the scale of the model:

{
	return scale;
}