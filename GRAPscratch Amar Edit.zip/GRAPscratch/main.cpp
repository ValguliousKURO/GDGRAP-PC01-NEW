// GRAPscratch.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

/*
the goal of this programming challenge is to implement a FPS movement using either keyboard or mouse inputs

the camera will be able to move forward, backward, left, right, up, and down

furthermore, the camera must be capable to spawn an object in front of the camera

the previously spawned objects must still be viewable in thw world



*/
#include <glad/glad.h>
#include <GLFW/glfw3.h>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <iostream>
#include <string>
#include "cmath"
#define _USE_MATH_DEFINES
#include <math.h>
#include "Model3D.h"

#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

#define TINYOBJLOADER_IMPLEMENTATION
#include "tiny_obj_loader.h"
#define PI 3.14159265358979
using namespace std;

Model3D model;
vector<Model3D> models;
float cameraSpeed = 0.5f;
float cameraSideSide = -90.0f;
float cameraUpDown = 0.0f;

float x_mod = 0;
float y_mod = -1.f;
float z_mod = -1.f;

float thetaX = 0;
float thetaY = 0;
float scale_x = 1.0;
float scale_y = 1.0;
float scale_z = 1.0;

float axis_x = 0.0;
float axis_y = 1.0;
float axis_z = 0.0;

glm::vec3 cameraPos = glm::vec3(0.0f, 0.0f, 6.0f);
glm::vec3 cameraFront = glm::vec3(0.0f, 0.0f, -1.0f);
glm::vec3 cameraUp = glm::vec3(0.0f, 1.0f, 0.0f);


void Key_Callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{

    /*
    
    void Key_Callback(GLFWwindow* window, int key, int scancode, int action, int mods)

    - listens to button Input from keyboard


	Camera controls: W, A, S, D, UP, DOWN, LEFT, RIGHT, SPACE

    Camera Movement:
    W - Moves camera forward
    S - Moves camera Backwards
    A - Moves camera to the Left
	D - Move camera to the Right

    Both A and D use Normalize() function of the cross product between cameraFront and cameraUp to properly move the camera's position

    Camera Rotation:
    UP Arrow Key - rotates camera upwards
    DOWN Arrow Key - rotates camera downwards
    RIGHT Arrow key - rotates camera to the right
    LEFT Arrow key - rotates camera to the left

    spawning object:
    SPACE - spawns the object model
    */
    if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
    {
        glfwSetWindowShouldClose(window, GLFW_TRUE);
    }

    if (key == GLFW_KEY_W)
    { 
        cameraPos += cameraSpeed * cameraFront;
	}

    if (key == GLFW_KEY_S)
    {
        cameraPos -= cameraSpeed * cameraFront;
    }

    if (key == GLFW_KEY_A)
    { 
        cameraPos -= glm::normalize(glm::cross(cameraFront, cameraUp)) * cameraSpeed;
	}

    if (key == GLFW_KEY_D)
    {
        cameraPos += glm::normalize(glm::cross(cameraFront, cameraUp)) * cameraSpeed;
    }

	if (key == GLFW_KEY_Z) 
    {
		z_mod += 0.1;
	}

	if (key == GLFW_KEY_X) 
    {
		z_mod -= 0.1;
	}

    if (key == GLFW_KEY_UP)
    {
        cameraUpDown += 2.0f;
	}

    if (key == GLFW_KEY_DOWN)
    {
        cameraUpDown -= 2.0f;
    }

    if (key == GLFW_KEY_LEFT)
    {
        cameraSideSide -= 2.0f;
    }

    if (key == GLFW_KEY_RIGHT)
    {
        cameraSideSide += 2.0f;
    }

	if (key == GLFW_KEY_E) 
    {
		scale_x += 0.1;
		scale_y += 0.1;
	}

	if (key == GLFW_KEY_Q) 
    {
		scale_x -= 0.1;
		scale_y -= 0.1;
	}

    if (key == GLFW_KEY_R) 
    {
		thetaX += 1.0f;
    }

    if (key == GLFW_KEY_T) 
    {
        thetaY += 1.0f;
    }

    if (key == GLFW_KEY_SPACE && action == GLFW_PRESS) 
    {
        /* Spawn function:
        
        - upon triggering the input condition, gets the position of the camera and offsets it by 10.0f
          using Model3D.setPosition(transformation, spawnPos)

          afterwards, it is push into the models vector
        */

        glm::vec3 spawnPos = cameraPos + cameraFront * 10.0f;  // Spawn model in front of the camera cube 6.0f (somewhat fixed by just increasing the float value)
        glm::mat4 transformation = glm::mat4(1.0f); //set  matrix
        model.setPosition(transformation, spawnPos);
        models.push_back(model);
    }
    /*
    updates and normalize the camera position and rotation with the new values from the keyboard inputs:
    
    */
    glm::vec3 front;
    front.x = cos(glm::radians(cameraSideSide)) * cos(glm::radians(cameraUpDown));
    front.y = sin(glm::radians(cameraUpDown));
    front.z = sin(glm::radians(cameraSideSide)) * cos(glm::radians(cameraUpDown));
    cameraFront = glm::normalize(front);

    
}




int main(void)
{
    
    GLFWwindow* window;

    /* Initialize the library */
    if (!glfwInit())
        return -1;

	float windowWidth = 600.f;
	float windowHeight = 600.f;

    /* Create a windowed mode window and its OpenGL context */
    window = glfwCreateWindow(windowWidth, windowHeight, "Amar, Dacanay, Villanueva", NULL, NULL);
    if (!window)
    {
        glfwTerminate();
        return -1;
    }

    /* Make the window's context current */
    glfwMakeContextCurrent(window);
	gladLoadGL();

    GLfloat UV[]{
    0.f, 1.f,
    0.f, 0.f,
    1.f, 1.f,
    1.f, 0.f,
    1.f, 1.f,
    1.f, 0.f,
    0.f, 1.f,
    0.f, 0.f
    };

    stbi_set_flip_vertically_on_load(true);

    int img_width, img_height, color_channels; //color channels ranges from 3 - 4 (RGB - RGBA)
    //3 == RGB JPGS !tranparency
    //4 == RGBA PNGS transparency

    unsigned char* tex_bytes = stbi_load(
        "3D/Red.png",
        &img_width,
        &img_height,
        &color_channels,
        0
    );

	glfwSetKeyCallback(window, Key_Callback);

	glViewport(0, 0, 600, 600);
    
    fstream vertSrc("Shaders/sample.vert");
    stringstream vertBuff;
    vertBuff << vertSrc.rdbuf();
    string vertS = vertBuff.str();
    const char* v = vertS.c_str();

	fstream fragSrc("Shaders/sample.frag");
	stringstream fragBuff;
	fragBuff << fragSrc.rdbuf();
	string fragS = fragBuff.str();
	const char* f = fragS.c_str();

    //create vertex shader
	GLuint vertexShader = glCreateShader(GL_VERTEX_SHADER);
    //assign the src to vertex shader
	glShaderSource(vertexShader, 1, &v, NULL);
	//compile the shader
	glCompileShader(vertexShader);

	//create fragment shader
	GLuint fragShader = glCreateShader(GL_FRAGMENT_SHADER);
	//assign the src to fragment shader
	glShaderSource(fragShader, 1, &f, NULL);
	//compile the shader
	glCompileShader(fragShader);

	//create shader program
	GLuint shaderProg = glCreateProgram();
	//attach the compiled shaders to the program
	glAttachShader(shaderProg, vertexShader);
	glAttachShader(shaderProg, fragShader);
	//link the program
	glLinkProgram(shaderProg);


    std::string path = "3D/RedBellPepper.obj";
    std::vector<tinyobj::shape_t> shapes;
    std::vector < tinyobj::material_t> material;
    std::string warning, error;

    tinyobj::attrib_t attributes; //positions, texture data, and etc.

    bool success = tinyobj::LoadObj(
        &attributes,
        &shapes,
        &material,
        &warning,
        &error,
        path.c_str()
    );

    std::vector<GLuint> mesh_indices;


    for (int i = 0; i < shapes[0].mesh.indices.size(); i++)
    {
        mesh_indices.push_back(shapes[0].mesh.indices[i].vertex_index);
    }

	GLfloat vertices[] {
		0.0f, 0.5f, 0.f, // Vertex 1 (X, Y, Z)
		-0.5f, -0.f, 0.f, // Vertex 2 (X, Y, Z)
		0.5f, -0.f, 0.f // Vertex 3 (X, Y, Z)
	};

    GLuint indices[]
    {
        0, 1, 2
    };

    GLuint texture;
    glGenTextures(1, &texture);
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, texture);

    glTexImage2D(
        GL_TEXTURE_2D,
        0,
        GL_RGBA, //RGBA if 4 channels and RGB if 3 channels
        img_width,
        img_height,
        0, //border but if 0 it means no border
        GL_RGBA,
        GL_UNSIGNED_BYTE,
        tex_bytes
    );

    glGenerateMipmap(GL_TEXTURE_2D);
    stbi_image_free(tex_bytes);

	GLuint VAO, VBO, EBO, VBO_UV;
    glGenVertexArrays(1, &VAO);
    glGenBuffers(1, &VBO);
    glGenBuffers(1, &VBO_UV);
    glGenBuffers(1, &EBO);

    //current VAO = null
    glBindVertexArray(VAO);
	//current VBO = VBO
    glBindBuffer(GL_ARRAY_BUFFER, VBO);

    //Data
    glBufferData(GL_ARRAY_BUFFER,
        sizeof(GLfloat) * attributes.vertices.size(), //Size of buffer in bytes
        &attributes.vertices[0], //Array itself
        GL_STATIC_DRAW //Static Objects for moving object need to use GL_DYNAMIC_DRAW
    );

    //Describes how to read data
    glVertexAttribPointer(
        //0 Position Data
        0, //Attrib Index-Index of VBO
        3, // X , Y , Z
        GL_FLOAT, //Array of GL floats
        GL_FALSE, //Is normalized?
        3 * sizeof(GLfloat), //size of components in bytes
        (void*)0 //stride value
    );


    float bytes = (sizeof(GLfloat)) * (sizeof(UV) / sizeof(UV[0]));
    glBindBuffer(GL_ARRAY_BUFFER, VBO_UV);
    glBufferData(GL_ARRAY_BUFFER, bytes, &UV[0], GL_STATIC_DRAW);
    glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 2 * sizeof(GLfloat), (void*)0);



    //current VBO = VBO
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBO);
    //current VBO = EBO
    //current VAO.VBO.append(EBO)

    glBufferData(GL_ELEMENT_ARRAY_BUFFER,
        sizeof(GLuint) * mesh_indices.size(),
        mesh_indices.data(),
        GL_STATIC_DRAW
    );

    //enables attrib index 0
    glEnableVertexAttribArray(0);
    glEnableVertexAttribArray(2);

    glBindBuffer(GL_ARRAY_BUFFER, 0);

    glBindVertexArray(0);
	glm::mat4 identity_matrix = glm::mat4(1.0f);

	glm::mat4 projectionMatrix = glm::perspective(
		glm::radians(60.f), //fov
		windowHeight / windowWidth, // aspect ratio
		0.1f, //zNear
		100.f); //zFar
    
    glEnable(GL_DEPTH_TEST);

    Model3D initialModel;
    glm::vec3 initialPos = glm::vec3(-0.5f, -0.5f, -4.5f); //(0.0f, 0.0f, 0.0f) -5.0
    glm::mat4 initialTransformation = glm::mat4(1.0f); 
    initialModel.setPosition(initialTransformation, initialPos);
    models.push_back(initialModel);
    //thetaY++;

    /* Loop until the user closes the window */
    while (!glfwWindowShouldClose(window))
    {
        /* Render here */
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
        
		
		
        glm::mat4 viewMatrix = glm::lookAt(cameraPos, cameraPos + cameraFront, cameraUp);

        glm::vec3 transPos = glm::vec3(x_mod, y_mod, z_mod);
        glm::vec3 scalePos = glm::vec3(scale_x, scale_y, scale_z);
            
        glm::mat4 transformation = glm::mat4(1.0f);
		model.setPosition(transformation, transPos);
		model.setScale(transformation, scalePos);

        transformation = glm::rotate(transformation, glm::radians(100.f), glm::normalize(glm::vec3(axis_x, axis_y, axis_z)));

        transformation = glm::rotate(transformation, glm::radians(thetaX), glm::normalize(glm::vec3(1.0f, 0.0f, 0.0f)));

        unsigned int viewLoc = glGetUniformLocation(shaderProg, "view");
        glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(viewMatrix));

        unsigned int projLoc = glGetUniformLocation(shaderProg, "projection");
        glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projectionMatrix));

        // use compiled shaders

        glBindTexture(GL_TEXTURE_2D, texture);
        GLuint tex0Address = glGetUniformLocation(shaderProg, "tex0");
        glUniform1i(tex0Address, 0);

		glUseProgram(shaderProg);

        /*
        
        for loop method:

        every model that is in the models vector is drawn in the while (!glfwWindowShouldClose(window))

        this is to ensure that each spawned model will constantly be loaded and drawn in the while loop

        the model is drawn  using the drawModel() function

        */

        for (size_t i = 0; i < models.size(); ++i) 
        {
            glm::mat4 transformation = models[i].getTransMatrix();
            unsigned int transformLoc = glGetUniformLocation(shaderProg, "transform");
            glUniformMatrix4fv(transformLoc, 1, GL_FALSE, glm::value_ptr(transformation));

            models[i].drawModel(VAO, mesh_indices);
        }

	    model.drawModel(VAO, mesh_indices);
       
        glEnd();    

        /* Swap front and back buffers */
        glfwSwapBuffers(window);

        /* Poll for and process events */
        glfwPollEvents();
    }

    glDeleteVertexArrays(1, &VAO);
    glDeleteBuffers(1, &VBO);
    glDeleteBuffers(1, &EBO);

    glfwTerminate();
    return 0;
}