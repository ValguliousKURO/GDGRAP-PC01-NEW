// GRAPscratch.cpp : This file contains the 'main' function. Program execution begins and ends there.
//
#include <glad/glad.h>
#include <GLFW/glfw3.h>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <iostream>
#include <string>
#include "cmath"
#define _USE_MATH_DEFINES
#include <math.h>
#include "Model3D.h"

#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

#define TINYOBJLOADER_IMPLEMENTATION
#include "tiny_obj_loader.h"
#define PI 3.14159265358979
using namespace std;


float x_mod = 0;
float y_mod = -1.f;
float z_mod = -1.f;

float thetaX = 0;
float thetaY = 0;
float scale_x = 1.0;
float scale_y = 1.0;
float scale_z = 1.0;

float axis_x = 0.0;
float axis_y = 1.0;
float axis_z = 0.0;
Model3D model;
//vector<glm::mat4> modelTransformations = { glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, 0.0f, 0.0f)) };
vector<Model3D> models;
float cameraSpeed = 0.5f;
glm::vec3 cameraPos = glm::vec3(0.0f, 0.0f, 6.0f);
glm::vec3 cameraFront = glm::vec3(0.0f, 0.0f, -1.0f);
glm::vec3 cameraUp = glm::vec3(0.0f, 1.0f, 0.0f);
float cameraSideSide = -90.0f;
float cameraUpDown = 0.0f;

void Key_Callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
	if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
		glfwSetWindowShouldClose(window, GLFW_TRUE);

    if (key == GLFW_KEY_W)
        cameraPos += cameraSpeed * cameraFront;
    if (key == GLFW_KEY_S)
        cameraPos -= cameraSpeed * cameraFront;
    if (key == GLFW_KEY_A)
        cameraPos -= glm::normalize(glm::cross(cameraFront, cameraUp)) * cameraSpeed;
    if (key == GLFW_KEY_D)
        cameraPos += glm::normalize(glm::cross(cameraFront, cameraUp)) * cameraSpeed;

	if (key == GLFW_KEY_Z) {
		z_mod += 0.1;
	}

	if (key == GLFW_KEY_X) {
		z_mod -= 0.1;
	}

    if (key == GLFW_KEY_UP)
        cameraUpDown += 2.0f;
    if (key == GLFW_KEY_DOWN)
        cameraUpDown -= 2.0f;
    if (key == GLFW_KEY_LEFT)
        cameraSideSide -= 2.0f;
    if (key == GLFW_KEY_RIGHT)
        cameraSideSide += 2.0f;

	if (key == GLFW_KEY_E) {
		scale_x += 0.1;
		scale_y += 0.1;
	}

	if (key == GLFW_KEY_Q) {
		scale_x -= 0.1;
		scale_y -= 0.1;
	}

    if (key == GLFW_KEY_R) {
		thetaX += 1.0f;
    }

    if (key == GLFW_KEY_T) {
        thetaY += 1.0f;
    }

    if (key == GLFW_KEY_SPACE && action == GLFW_PRESS) {
        // Spawn model in front of the camera
        //Model3D model2;
        glm::vec3 spawnPos = cameraPos + cameraFront * 6.0f;
        //glm::mat4 transformation = glm::translate(glm::mat4(1.0f), spawnPos);
        glm::mat4 transformation = glm::mat4(1.0f);
        model.setPosition(transformation, spawnPos);
        //transformation = model.getTransMatrix();
        //modelTransformations.push_back(transformation);
        models.push_back(model);
    }

    glm::vec3 front;
    front.x = cos(glm::radians(cameraSideSide)) * cos(glm::radians(cameraUpDown));
    front.y = sin(glm::radians(cameraUpDown));
    front.z = sin(glm::radians(cameraSideSide)) * cos(glm::radians(cameraUpDown));
    cameraFront = glm::normalize(front);

    
}




int main(void)
{
    


    GLFWwindow* window;

    /* Initialize the library */
    if (!glfwInit())
        return -1;

	float windowWidth = 600.f;
	float windowHeight = 600.f;

    /* Create a windowed mode window and its OpenGL context */
    window = glfwCreateWindow(windowWidth, windowHeight, "Arvin Lawrence B. Dacanay", NULL, NULL);
    if (!window)
    {
        glfwTerminate();
        return -1;
    }



    /* Make the window's context current */
    glfwMakeContextCurrent(window);
	gladLoadGL();

    GLfloat UV[]{
    0.f, 1.f,
    0.f, 0.f,
    1.f, 1.f,
    1.f, 0.f,
    1.f, 1.f,
    1.f, 0.f,
    0.f, 1.f,
    0.f, 0.f
    };


    stbi_set_flip_vertically_on_load(true);

    int img_width, img_height, color_channels; //color channels ranges from 3 - 4 (RGB - RGBA)
    //3 == RGB JPGS !tranparency
    //4 == RGBA PNGS transparency

    unsigned char* tex_bytes = stbi_load(
        "3D/ayaya.png",
        &img_width,
        &img_height,
        &color_channels,
        0
    );

	glfwSetKeyCallback(window, Key_Callback);

	glViewport(0, 0, 600, 600);
    
    fstream vertSrc("Shaders/sample.vert");
    stringstream vertBuff;
    vertBuff << vertSrc.rdbuf();
    string vertS = vertBuff.str();
    const char* v = vertS.c_str();

	fstream fragSrc("Shaders/sample.frag");
	stringstream fragBuff;
	fragBuff << fragSrc.rdbuf();
	string fragS = fragBuff.str();
	const char* f = fragS.c_str();

    //create vertex shader
	GLuint vertexShader = glCreateShader(GL_VERTEX_SHADER);
    //assign the src to vertex shader
	glShaderSource(vertexShader, 1, &v, NULL);
	//compile the shader
	glCompileShader(vertexShader);

	//create fragment shader
	GLuint fragShader = glCreateShader(GL_FRAGMENT_SHADER);
	//assign the src to fragment shader
	glShaderSource(fragShader, 1, &f, NULL);
	//compile the shader
	glCompileShader(fragShader);

	//create shader program
	GLuint shaderProg = glCreateProgram();
	//attach the compiled shaders to the program
	glAttachShader(shaderProg, vertexShader);
	glAttachShader(shaderProg, fragShader);
	//link the program
	glLinkProgram(shaderProg);







    std::string path = "3D/myCube.obj";
    std::vector<tinyobj::shape_t> shapes;
    std::vector < tinyobj::material_t> material;
    std::string warning, error;

    tinyobj::attrib_t attributes; //positions, texture data, and etc.

    bool success = tinyobj::LoadObj(
        &attributes,
        &shapes,
        &material,
        &warning,
        &error,
        path.c_str()
    );

    std::vector<GLuint> mesh_indices;


    for (int i = 0; i < shapes[0].mesh.indices.size(); i++)
    {
        mesh_indices.push_back(shapes[0].mesh.indices[i].vertex_index);
    }

	GLfloat vertices[] {
		0.0f, 0.5f, 0.f, // Vertex 1 (X, Y, Z)
		-0.5f, -0.f, 0.f, // Vertex 2 (X, Y, Z)
		0.5f, -0.f, 0.f // Vertex 3 (X, Y, Z)
	};

    GLuint indices[]
    {
        0, 1, 2
    };



    GLuint texture;
    glGenTextures(1, &texture);
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, texture);

    glTexImage2D(
        GL_TEXTURE_2D,
        0,
        GL_RGBA, //RGBA if 4 channels and RGB if 3 channels
        img_width,
        img_height,
        0, //border but if 0 it means no border
        GL_RGBA,
        GL_UNSIGNED_BYTE,
        tex_bytes
    );

    glGenerateMipmap(GL_TEXTURE_2D);
    stbi_image_free(tex_bytes);

	GLuint VAO, VBO, EBO, VBO_UV;
    glGenVertexArrays(1, &VAO);
    glGenBuffers(1, &VBO);
    glGenBuffers(1, &VBO_UV);
    glGenBuffers(1, &EBO);

    //current VAO = null
    glBindVertexArray(VAO);
	//current VBO = VBO
    glBindBuffer(GL_ARRAY_BUFFER, VBO);

    //Data
    glBufferData(GL_ARRAY_BUFFER,
        sizeof(GLfloat) * attributes.vertices.size(), //Size of buffer in bytes
        &attributes.vertices[0], //Array itself
        GL_STATIC_DRAW //Static Objects for moving object need to use GL_DYNAMIC_DRAW
    );

    //Describes how to read data
    glVertexAttribPointer(
        //0 Position Data
        0, //Attrib Index-Index of VBO
        3, // X , Y , Z
        GL_FLOAT, //Array of GL floats
        GL_FALSE, //Is normalized?
        3 * sizeof(GLfloat), //size of components in bytes
        (void*)0 //stride value
    );


    float bytes = (sizeof(GLfloat)) * (sizeof(UV) / sizeof(UV[0]));
    glBindBuffer(GL_ARRAY_BUFFER, VBO_UV);
    glBufferData(GL_ARRAY_BUFFER, bytes, &UV[0], GL_STATIC_DRAW);
    glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 2 * sizeof(GLfloat), (void*)0);



    //current VBO = VBO
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBO);
    //current VBO = EBO
    //current VAO.VBO.append(EBO)

    glBufferData(GL_ELEMENT_ARRAY_BUFFER,
        sizeof(GLuint) * mesh_indices.size(),
        mesh_indices.data(),
        GL_STATIC_DRAW
    );

    //enables attrib index 0
    glEnableVertexAttribArray(0);
    glEnableVertexAttribArray(2);

    glBindBuffer(GL_ARRAY_BUFFER, 0);

    glBindVertexArray(0);
	glm::mat4 identity_matrix = glm::mat4(1.0f);
	//glm::mat3 identity_matrix = glm::mat3(1.0f);

	//glm::mat4 projectionMatrix = glm::ortho(-2.0f,//left
	//	2.0f,//right
	//	-2.0f, //bottom
	//	2.0f, //top
	//	-1.0f, //zNear
	//	1.0f); //zFar

	glm::mat4 projectionMatrix = glm::perspective(
		glm::radians(60.f), //fov
		windowHeight / windowWidth, // aspect ratio
		0.1f, //zNear
		100.f); //zFar
    
    glEnable(GL_DEPTH_TEST);

    Model3D initialModel;
    glm::vec3 initialPos = glm::vec3(0.0f, 0.0f, 0.0f);
    glm::mat4 initialTransformation = glm::mat4(1.0f);
    initialModel.setPosition(initialTransformation, initialPos);
    models.push_back(initialModel);
    //thetaY++;
    /* Loop until the user closes the window */
    while (!glfwWindowShouldClose(window))
    {
        /* Render here */
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
        //glBegin(GL_POLYGON);
        
		
		
        glm::mat4 viewMatrix = glm::lookAt(cameraPos, cameraPos + cameraFront, cameraUp);
       // for (int i = 0; i < 3; ++i)
        //{
        glm::vec3 transPos = glm::vec3(x_mod, y_mod, z_mod);
        glm::vec3 scalePos = glm::vec3(scale_x, scale_y, scale_z);
            
        glm::mat4 transformation = glm::mat4(1.0f);
		model.setPosition(transformation, transPos);
		model.setScale(transformation, scalePos);
		//model.setRotation(transformation, thetaY, 'y');
            transformation = glm::rotate(transformation,
                glm::radians(100.f),
                glm::normalize(glm::vec3(axis_x, axis_y, axis_z)));

            transformation = glm::rotate(
                transformation,
                glm::radians(thetaX),
                glm::normalize(glm::vec3(1.0f, 0.0f, 0.0f)));

            /*transformation = glm::rotate(
                transformation,
                glm::radians(120 * i + theta),
                glm::normalize(glm::vec3(0.0f, 0.0f, 1.0f)));*/

            unsigned int viewLoc = glGetUniformLocation(shaderProg, "view");
            glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(viewMatrix));

            unsigned int projLoc = glGetUniformLocation(shaderProg, "projection");
            glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projectionMatrix));

        

        // use compiled shaders


        glBindTexture(GL_TEXTURE_2D, texture);
        GLuint tex0Address = glGetUniformLocation(shaderProg, "tex0");
        glUniform1i(tex0Address, 0);

		glUseProgram(shaderProg);

       

        for (size_t i = 0; i < models.size(); ++i) {
        //for (size_t i = 0; i < modelTransformations.size(); ++i) {
           
            //glm::mat4 transformation = modelTransformations[i];
            glm::mat4 transformation = models[i].getTransMatrix();
            unsigned int transformLoc = glGetUniformLocation(shaderProg, "transform");
            glUniformMatrix4fv(transformLoc, 1, GL_FALSE, glm::value_ptr(transformation));
            //glDrawElements(GL_TRIANGLES, mesh_indices.size(), GL_UNSIGNED_INT, 0);
            models[i].drawModel(VAO, mesh_indices);
			//model.drawModel(VAO, mesh_indices);
        }
       /*glBindVertexArray(VAO);

       glDrawElements(GL_TRIANGLES, mesh_indices.size(), GL_UNSIGNED_INT, 0);*/

	   model.drawModel(VAO, mesh_indices);
       
        glEnd();    

        /* Swap front and back buffers */
        glfwSwapBuffers(window);

        /* Poll for and process events */
        glfwPollEvents();
    }

    glDeleteVertexArrays(1, &VAO);
    glDeleteBuffers(1, &VBO);
    glDeleteBuffers(1, &EBO);

    glfwTerminate();
    return 0;
}